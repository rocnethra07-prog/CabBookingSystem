package cabBookingService.model;

import java.util.Objects;


//Credentials related class : for password

public class UserAuth {
    private final String userId;
    private final String hashedPassword;

    public UserAuth(String userId, String password){
        this.userId =  userId;
        this.hashedPassword = hash(password.trim());
    }

    public boolean checkPassword(String inputPassword){
        if(inputPassword == null || inputPassword.isBlank()){
            return false;
        }
        return Objects.equals(this.hashedPassword, hash(inputPassword));
    }

    private String hash(String password){
        return Integer.toHexString(password.hashCode());
    }

    @Override
    public boolean equals(Object object) {
        if(this == object) {
            return true;
        }
        if (!(object instanceof UserAuth userAuth)) return false;
        return Objects.equals(userId, userAuth.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(userId);
    }
}
